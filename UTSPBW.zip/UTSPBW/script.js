document.querySelector('.back-to-home').addEventListener('click', function(e) {
    e.preventDefault(); 
    window.scrollTo(0, 0);
});

